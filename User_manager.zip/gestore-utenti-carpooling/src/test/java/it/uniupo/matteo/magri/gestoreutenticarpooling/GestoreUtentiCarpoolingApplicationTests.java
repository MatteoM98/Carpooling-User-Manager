package it.uniupo.matteo.magri.gestoreutenticarpooling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestoreUtentiCarpoolingApplicationTests {

	@Test
	void contextLoads() {
	}

}
