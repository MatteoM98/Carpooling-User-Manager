package it.uniupo.matteo.magri.gestoreutenticarpooling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestoreUtentiCarpoolingApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestoreUtentiCarpoolingApplication.class, args);
	}

}
