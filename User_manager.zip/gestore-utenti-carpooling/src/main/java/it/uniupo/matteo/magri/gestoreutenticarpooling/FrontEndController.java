package it.uniupo.matteo.magri.gestoreutenticarpooling;

import javax.servlet.http.HttpServletRequest;

import org.keycloak.KeycloakSecurityContext;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeoutException;

@RestController
public class FrontEndController {
	private Connection connection;
	private Channel channel;
	private final static String HOST = "localhost";
	private final static String USER = "admin";
	private final static String PASSWD = "admin";

	// Accedo per recuperare le informazioni degli utenti
	@GetMapping(value = "/getUserInfo")
	public void getUserInfo(HttpServletRequest request)
			throws IOException, TimeoutException, InterruptedException, JSONException {
		String token = getKeycloakSecurityContext(request).getTokenString();
		String userId = getKeycloakSecurityContext(request).getToken().getSubject();
		//String userId = "";
		// chiamata al gestore utente
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setConnectionTimeout(300000);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);
		connection = factory.newConnection();
		channel = connection.createChannel();
		// messaggio RPC
		JSONObject messageJSON = new JSONObject();
		messageJSON.put("token", token);
		messageJSON.put("param", userId);
		String query = messageJSON.toString();
		String requestQueueName = "rpc_get_user_info"; // coda dove invia il client ed il server rimane in attesa
		String response = call(query, requestQueueName);
		// stampa completa dell' utente
		System.out.println("\n\n********************");
		System.out.println("Richiesta recupero info dell' utente con ID: " + userId);
		System.out.println("Ecco la risposta dal server:\n");
		System.out.println(response);
	}

	// Accedo per aggiungere un utente
	@GetMapping(value = "/addUser")
	public void addUser(HttpServletRequest request)
			throws IOException, TimeoutException, InterruptedException, JSONException {
		String userId = getKeycloakSecurityContext(request).getToken().getSubject();
		/*
		 * Simulo di aver ottenuto l' id, ma dato che per motivi dimostrativi sto usando
		 * un unico utente presente sull' auth server, cambio l'id per evitare problemi
		 * di conflitto all' interno del database
		 */
		userId = UUID.randomUUID().toString();
		// chiamata al gestore utente
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setConnectionTimeout(300000);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);
		connection = factory.newConnection();
		channel = connection.createChannel();
		// messaggio RPC
		JSONObject params = new JSONObject();
		params.put("UserID", userId);
		params.put("nome", "Francesco");
		params.put("cognome", "Neri");
		params.put("email", "franceso.neri88@gmail.com");
		params.put("dOb", "1988-12-24");
		params.put("username", "francoBlack");
		JSONObject messageJSON = new JSONObject();
		messageJSON.put("param", params);
		String query = messageJSON.toString();
		String requestQueueName = "rpc_add_user";
		String response = call(query, requestQueueName);
		// stampa completa dell' utente
		System.out.println("\n\n********************");
		System.out.println("Richiesta aggiunta dell' utente con ID " + userId);
		System.out.println("Ecco la risposta dal server:\n");
		System.out.println(response);
	}

	// Accedo per aggiungere un car controller
	@GetMapping(value = "/addCC")
	public void addCC(HttpServletRequest request)
			throws IOException, TimeoutException, InterruptedException, JSONException {
		String token = getKeycloakSecurityContext(request).getTokenString();
		// chiamata al gestore utente
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setConnectionTimeout(300000);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);
		connection = factory.newConnection();
		channel = connection.createChannel();
		// messaggio RPC
		JSONObject params = new JSONObject();
		params.put("descr", "Berlina monovolume, full optional, immatricolata nel 2010");
		params.put("nposti", "4");
		JSONObject messageJSON = new JSONObject();
		messageJSON.put("token", token);
		messageJSON.put("param", params);
		String query = messageJSON.toString();
		String requestQueueName = "rpc_add_cc";
		String response = call(query, requestQueueName);
		// stampa completa dell' utente
		System.out.println("\n\n********************");
		System.out.println("Richiesta aggiunta di un nuovo CC");
		System.out.println("Ecco la risposta dal server:\n");
		System.out.println(response);
	}

	// Accedo per modificare descrizione di un car controller
	@GetMapping(value = "/alterDescription")
	public void alterDescription(HttpServletRequest request)
			throws IOException, TimeoutException, InterruptedException, JSONException {
		String token = getKeycloakSecurityContext(request).getTokenString();
		// chiamata al gestore utente
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setConnectionTimeout(300000);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);
		connection = factory.newConnection();
		channel = connection.createChannel();
		// messaggio RPC
		JSONObject params = new JSONObject();
		params.put("newDescr", "Mercedes Benz A180d, full optional, immatricolata nel 2012, serie A");
		params.put("ccID", "bb5d2184-078f-43d7-91b6-2bb94cf1e40d"); // <---- ID del CC da modificare
		JSONObject messageJSON = new JSONObject();
		messageJSON.put("token", token);
		messageJSON.put("param", params);
		String query = messageJSON.toString();
		String requestQueueName = "rpc_alter_descr";
		String response = call(query, requestQueueName);
		// stampa completa dell' utente
		System.out.println("\n\n********************");
		System.out.println("Richiesta modifica descrizione di un CC");
		System.out.println("Ecco la risposta dal server:\n");
		System.out.println(response);
	}

	// Accedo per cancellare un car controller
	@GetMapping(value = "/deleteCC")
	public void deleteCC(HttpServletRequest request)
			throws IOException, TimeoutException, InterruptedException, JSONException {
		String token = getKeycloakSecurityContext(request).getTokenString();
		// chiamata al gestore utente
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setConnectionTimeout(300000);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);
		connection = factory.newConnection();
		channel = connection.createChannel();
		// messaggio RPC
		JSONObject messageJSON = new JSONObject();
		messageJSON.put("token", token);
		messageJSON.put("param", "bb5d2184-078f-43d7-91b6-2bb94cf1e40d"); // <-- ID del CC da eliminare
		String query = messageJSON.toString();
		String requestQueueName = "rpc_delete_cc";
		String response = call(query, requestQueueName);
		// stampa completa dell' utente
		System.out.println("\n\n********************");
		System.out.println("Richiesta eliminazione di un CC");
		System.out.println("Ecco la risposta dal server:\n");
		System.out.println(response);
	}

	// Accedo per cancellare un utente
	@GetMapping(value = "/deleteUser")
	public void deleteUser(HttpServletRequest request)
			throws IOException, TimeoutException, InterruptedException, JSONException {
		String token = getKeycloakSecurityContext(request).getTokenString();
		// chiamata al gestore utente
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setConnectionTimeout(300000);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);
		connection = factory.newConnection();
		channel = connection.createChannel();
		// messaggio RPC
		JSONObject messageJSON = new JSONObject();
		messageJSON.put("token", token);
		messageJSON.put("param", "de9ebdcf-0c8c-4322-ba8e-b7559dfa9ffc"); // <-- ID dell utente da eliminare
		String query = messageJSON.toString();
		String requestQueueName = "rpc_delete_user";
		String response = call(query, requestQueueName);
		// stampa completa dell' utente
		System.out.println("\n\n********************");
		System.out.println("Richiesta eliminazione di un utente");
		System.out.println("Ecco la risposta dal server:\n");
		System.out.println(response);
	}

	// Accedo per recuperare le informazioni degli utenti
	@GetMapping(value = "/getCCInfo")
	public void getCCInfo(HttpServletRequest request)
			throws IOException, TimeoutException, InterruptedException, JSONException {
		String token = getKeycloakSecurityContext(request).getTokenString();
		// chiamata al gestore utente
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setConnectionTimeout(300000);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);
		connection = factory.newConnection();
		channel = connection.createChannel();
		// messaggio RPC
		JSONObject messageJSON = new JSONObject();
		messageJSON.put("token", token);
		messageJSON.put("param", "bb5d2184-078f-43d7-91b6-2bb94cf1e40d"); // <--- ID del CC
		String query = messageJSON.toString();
		String requestQueueName = "rpc_get_cc_info";
		String response = call(query, requestQueueName);
		// stampa completa dell' utente
		System.out.println("\n\n********************");
		System.out.println("Richiesta recupero informazioni di un CC");
		System.out.println("Ecco la risposta dal server:\n");
		System.out.println(response);
	}

	// Accedo per recuperare l' ID di un CC associato ad un utente
	@GetMapping(value = "/getCCID")
	public void getCCID(HttpServletRequest request)
			throws IOException, TimeoutException, InterruptedException, JSONException {
		String token = getKeycloakSecurityContext(request).getTokenString();
		// chiamata al gestore utente
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setConnectionTimeout(300000);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);
		connection = factory.newConnection();
		channel = connection.createChannel();
		// messaggio RPC
		JSONObject messageJSON = new JSONObject();
		messageJSON.put("token", token);
		messageJSON.put("param", "50f28974-c0a5-43d0-9b4d-f91b68472f37"); // <--- ID dell utente
		String query = messageJSON.toString();
		String requestQueueName = "rpc_get_cc_id";
		String response = call(query, requestQueueName);
		// stampa completa dell' utente
		System.out.println("\n\n********************");
		System.out.println("Richiesta recupero ID di un CC");
		System.out.println("Ecco la risposta dal server:\n");
		System.out.println(response);
	}

	// Accedo per recuperare le info di un CC associate ad un utente
	@GetMapping(value = "/getCCInfoUser")
	public void getCCInfoUser(HttpServletRequest request)
			throws IOException, TimeoutException, InterruptedException, JSONException {
		String token = getKeycloakSecurityContext(request).getTokenString();
		// chiamata al gestore utente
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setConnectionTimeout(300000);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);
		connection = factory.newConnection();
		channel = connection.createChannel();
		// messaggio RPC
		JSONObject messageJSON = new JSONObject();
		messageJSON.put("token", token);
		messageJSON.put("param", "50f28974-c0a5-43d0-9b4d-f91b68472f37"); // <--- ID dell utente
		String query = messageJSON.toString();
		String requestQueueName = "rpc_get_cc_info_user";
		String response = call(query, requestQueueName);
		// stampa completa dell' utente
		System.out.println("\n\n********************");
		System.out.println("Richiesta recupero informazioni di un CC dato l' id dell' utente");
		System.out.println("Ecco la risposta dal server:\n");
		System.out.println(response);
	}

	// Accedo per recuperare il numero di posti associati ad un CC
	@GetMapping(value = "/getSeats")
	public void getSeats(HttpServletRequest request)
			throws IOException, TimeoutException, InterruptedException, JSONException {
		String token = getKeycloakSecurityContext(request).getTokenString();
		// chiamata al gestore utente
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setConnectionTimeout(300000);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);
		connection = factory.newConnection();
		channel = connection.createChannel();
		// messaggio RPC
		JSONObject messageJSON = new JSONObject();
		messageJSON.put("token", token);
		messageJSON.put("param", "bb5d2184-078f-43d7-91b6-2bb94cf1e40d"); // <--- ID del CC
		String query = messageJSON.toString();
		String requestQueueName = "rpc_get_seats";
		String response = call(query, requestQueueName);
		// stampa completa dell' utente
		System.out.println("\n\n********************");
		System.out.println("Richiesta recupero numero posti di un CC");
		System.out.println("Ecco la risposta dal server:\n");
		System.out.println(response);
	}

	// Accedo per recuperare lo stato di un CC
	@GetMapping(value = "/getStatusCC")
	public void getStatusCC(HttpServletRequest request)
			throws IOException, TimeoutException, InterruptedException, JSONException {
		String token = getKeycloakSecurityContext(request).getTokenString();
		// chiamata al gestore utente
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setConnectionTimeout(300000);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);
		connection = factory.newConnection();
		channel = connection.createChannel();
		// messaggio RPC
		JSONObject messageJSON = new JSONObject();
		messageJSON.put("token", token);
		messageJSON.put("param", "bb5d2184-078f-43d7-91b6-2bb94cf1e40d"); // <--- ID del CC
		String query = messageJSON.toString();
		String requestQueueName = "rpc_get_status";
		String response = call(query, requestQueueName);
		// stampa completa dell' utente
		System.out.println("\n\n********************");
		System.out.println("Richiesta recupero stato di un CC");
		System.out.println("Ecco la risposta dal server:\n");
		System.out.println(response);
	}
	
	// Accedo per modificare lo stato di un CC
		@GetMapping(value = "/setStatus")
		public void setStatus(HttpServletRequest request)
				throws IOException, TimeoutException, InterruptedException, JSONException {
			String token = getKeycloakSecurityContext(request).getTokenString();
			// chiamata al gestore utente
			ConnectionFactory factory = new ConnectionFactory();
			factory.setHost(HOST);
			factory.setConnectionTimeout(300000);
			factory.setUsername(USER);
			factory.setPassword(PASSWD);
			connection = factory.newConnection();
			channel = connection.createChannel();
			// messaggio RPC
			JSONObject params = new JSONObject();
			params.put("newStato", "OFF");
			params.put("ccID", "bb5d2184-078f-43d7-91b6-2bb94cf1e40d"); // <---- ID del CC da modificare
			JSONObject messageJSON = new JSONObject();
			messageJSON.put("token", token);
			messageJSON.put("param", params);
			String query = messageJSON.toString();
			String requestQueueName = "rpc_set_status";
			String response = call(query, requestQueueName);
			// stampa completa dell' utente
			System.out.println("\n\n********************");
			System.out.println("Richiesta per modificare lo stato di un CC");
			System.out.println("Ecco la risposta dal server:\n");
			System.out.println(response);
		}
		
		// Accedo per recuperare l' ID dell' utente dato il suo username
		@GetMapping(value = "/getUserID")
		public void getUserID(HttpServletRequest request)
				throws IOException, TimeoutException, InterruptedException, JSONException {
			String token = getKeycloakSecurityContext(request).getTokenString();
			// chiamata al gestore utente
			ConnectionFactory factory = new ConnectionFactory();
			factory.setHost(HOST);
			factory.setConnectionTimeout(300000);
			factory.setUsername(USER);
			factory.setPassword(PASSWD);
			connection = factory.newConnection();
			channel = connection.createChannel();
			// messaggio RPC
			String username = "Italia001";   //<--- Username dell' utente di cui recuperare l' ID
			JSONObject messageJSON = new JSONObject();
			messageJSON.put("token", token);
			messageJSON.put("param", username);
			String query = messageJSON.toString();
			String requestQueueName = "rpc_get_user_id";
			String response = call(query, requestQueueName);
			// stampa completa dell' utente
			System.out.println("\n\n********************");
			System.out.println("Richiesta per recuperare ID di un utente dato l' username");
			System.out.println("Ecco la risposta dal server:\n");
			System.out.println(response);
		}
		
		// Accedo per recuperare le informazioni degli utenti
		@GetMapping(value = "/getUserInfoFromCC")
		public void getUserInfoFromCC(HttpServletRequest request)
				throws IOException, TimeoutException, InterruptedException, JSONException {
			String token = getKeycloakSecurityContext(request).getTokenString();
			// chiamata al gestore utente
			ConnectionFactory factory = new ConnectionFactory();
			factory.setHost(HOST);
			factory.setConnectionTimeout(300000);
			factory.setUsername(USER);
			factory.setPassword(PASSWD);
			connection = factory.newConnection();
			channel = connection.createChannel();
			// messaggio RPC
			JSONObject messageJSON = new JSONObject();
			messageJSON.put("token", token);
			messageJSON.put("param", "df400a5b-914b-47ee-8362-2caee16478eb"); //<-- ID del CC
			String query = messageJSON.toString();
			String requestQueueName = "rpc_get_user_info_from_cc"; // coda dove invia il client ed il server rimane in attesa
			String response = call(query, requestQueueName);
			// stampa completa dell' utente
			System.out.println("\n\n********************");
			System.out.println("Richiesta per recuperare le info di un utente dato l' id del CC associato");
			System.out.println("Ecco la risposta dal server:\n");
			System.out.println(response);
		}

	private KeycloakSecurityContext getKeycloakSecurityContext(HttpServletRequest request) {
		return (KeycloakSecurityContext) request.getAttribute(KeycloakSecurityContext.class.getName());
	}

	public String call(String message, String requestQueueName) throws IOException, InterruptedException {
		// Generazione UUID univoco per identificare la richiesta
		final String corrId = UUID.randomUUID().toString(); // correlationID della richiesta (per identificarla)

		String replyQueueName = channel.queueDeclare().getQueue(); // creo coda di risposta
		AMQP.BasicProperties props = new AMQP.BasicProperties.Builder().correlationId(corrId).replyTo(replyQueueName)
				.build(); // definisco la richiesta RPC: la coda in cui riceve la risposta
							// (replyQueueName) ed un valore univoco per la richiesta (corrId),

		// Pubblico il messaggio nella queue callback
		channel.basicPublish("", requestQueueName, props, message.getBytes("UTF-8"));

		final BlockingQueue<String> response = new ArrayBlockingQueue<>(1); // creo una coda di stringhe

		// Ricevo risposta e la inserisco nella coda
		String ctag = channel.basicConsume(replyQueueName, true, (consumerTag, delivery) -> { // avvio un consumatore
			if (delivery.getProperties().getCorrelationId().equals(corrId)) {
				response.offer(new String(delivery.getBody(), "UTF-8"));
				/*
				 * Inserisce l'elemento specificato in questa coda se è possibile farlo
				 * immediatamente senza violare le restrizioni di capacità, restituendo in
				 * truecaso di successo e falsese non è attualmente disponibile spazio.
				 */
			}
		}, consumerTag -> {
		});

		// Prelevo risposta dalla coda
		String result = response.take();
		channel.basicCancel(ctag); // cancella il cosumatore identificato da ctag
		// Restituisco la risposta
		return result;
	}

}
