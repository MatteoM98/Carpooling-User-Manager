package it.uniupo.matteo.magri.gestoreutenticarpooling;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.web.client.RestTemplate;

import javax.naming.CommunicationException;

public class PublicKeyRetriever {

    private final String reqUrl;
    private final RestTemplate restTemplate;

    public PublicKeyRetriever(String host, String realm, int port) {
        reqUrl = "http://" + host + ":" + port + "/auth/realms/" + realm;
        restTemplate = new RestTemplateBuilder().build();
    }

    //Formato JSON
    public String getPlainJson() {
        return restTemplate.getForObject(reqUrl, String.class);
    }

    //Recupero chiave pubblica del server in formato stringa
    public String getPublicKey() throws CommunicationException {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            JsonNode obj = objectMapper.readTree(getPlainJson());
            return obj.get("public_key").asText();
        } catch (JsonProcessingException e) {
            throw new CommunicationException();
        }
    }
}



