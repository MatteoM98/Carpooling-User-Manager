package it.uniupo.matteo.magri.gestoreutenticarpooling;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;

import com.rabbitmq.client.*;

public class AlterDescription extends Thread {

	// Variabili
	private Delivery delivery;
	private Channel channel;

	// JDBC driver e URL database
	private final static String JDBC_DRIVER = "org.h2.Driver";
	private final static String DB_URL = "jdbc:h2:/home/enigma/test";
	// Credenziali databse
	private final static String USERDB = "matteo";
	private final static String PASSDB = "";

	// Costruttore
	public AlterDescription(Delivery delivery, Channel channel) {
		this.delivery = delivery;
		this.channel = channel;
	}

	@Override
	public void run() {
		AMQP.BasicProperties replyProps = new AMQP.BasicProperties.Builder()
				.correlationId(delivery.getProperties().getCorrelationId()).build();

		String response = ""; // stringa di risposta da inviare indietro

		try {
			// Leggo la richiesta
			String message;
			message = new String(delivery.getBody(), "UTF-8");
			System.out.println("Operazione richiesta: alterDescription");
			// elaboro message
			JSONObject obj = new JSONObject(message);
			String token = obj.getString("token");
			JSONObject param = obj.getJSONObject("param");
			String newDescr = param.getString("newDescr");
			String ccID = param.getString("ccID");
			// Verificare il token
			PublicKeyRetriever key = new PublicKeyRetriever("localhost", "Demo", 8080);
			TokenVerifier tokenVer = new TokenVerifier(key);
			if (tokenVer.verify(token)) {
				// Se la verifica va a termine, contatto il DB
				Connection conn = null;
				Statement stmt = null;
				Class.forName(JDBC_DRIVER);
				System.out.println("Connessione al database...");
				conn = DriverManager.getConnection(DB_URL, USERDB, PASSDB);
				System.out.println("Connessione eseguita con successo!!!");
				stmt = conn.createStatement();
				String sql = "UPDATE CarController SET Descrizione = " + "\'" + newDescr + "\'" + " WHERE ID = " + "\'"
						+ ccID + "\'";
				int rs = stmt.executeUpdate(sql);
				if (rs > 0) {
					response = "CC description modified";
				} else {
					response = "Resource error";
				}
			} else {
				// Altrimenti restituisco un token error
				response = "Token error";
			}
		} catch (RuntimeException | JSONException e) {
			response = "Resource error";
		} catch (ClassNotFoundException | UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Credenziali errate");
			e.printStackTrace();
		} finally {
			try {
				channel.basicPublish("", delivery.getProperties().getReplyTo(), replyProps, response.getBytes("UTF-8"));
				channel.basicAck(delivery.getEnvelope().getDeliveryTag(), false);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
