package it.uniupo.matteo.magri.gestoreutenticarpooling;

import com.rabbitmq.client.*;

public class BackEnd {

	// Code
	private static final String RPC_QUEUE_GET_USER_INFO = "rpc_get_user_info";
	private static final String RPC_QUEUE_ADD_USER = "rpc_add_user";
	private static final String RPC_QUEUE_ADD_CC = "rpc_add_cc";
	private static final String RPC_QUEUE_ALTER_DESCR = "rpc_alter_descr";
	private static final String RPC_QUEUE_DELETE_CC = "rpc_delete_cc";
	private static final String RPC_QUEUE_DELETE_USER = "rpc_delete_user";
	private static final String RPC_QUEUE_GET_CC_INFO = "rpc_get_cc_info";
	private static final String RPC_QUEUE_GET_CC_ID = "rpc_get_cc_id";
	private static final String RPC_QUEUE_GET_CC_INFO_USER = "rpc_get_cc_info_user";
	private static final String RPC_QUEUE_GET_SEATS = "rpc_get_seats";
	private static final String RPC_QUEUE_GET_STATUS = "rpc_get_status";
	private static final String RPC_QUEUE_SET_STATUS = "rpc_set_status";
	private static final String RPC_QUEUE_GET_USER_ID = "rpc_get_user_id";
	private static final String RPC_QUEUE_GET_USER_INFO_FROM_CC = "rpc_get_user_info_from_cc";
	// Credenziali
	private final static String HOST = "localhost";
	private final static String USER = "admin";
	private final static String PASSWD = "admin";

	public static void main(String[] argv) throws Exception {
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		factory.setUsername(USER);
		factory.setPassword(PASSWD);

		/*
		 * Stabilisco connessione e dichiaro la coda in cui attendo le richieste
		 */
		try {
			com.rabbitmq.client.Connection connection = factory.newConnection();
			com.rabbitmq.client.Channel channel = connection.createChannel();

			// dichiaro le varie code
			channel.queueDeclare(RPC_QUEUE_GET_USER_INFO, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_ADD_USER, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_ADD_CC, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_ALTER_DESCR, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_DELETE_CC, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_DELETE_USER, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_GET_CC_INFO, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_GET_CC_ID, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_GET_CC_INFO_USER, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_GET_SEATS, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_GET_STATUS, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_SET_STATUS, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_GET_USER_ID, false, false, false, null);
			channel.queueDeclare(RPC_QUEUE_GET_USER_INFO_FROM_CC, false, false, false, null);

			// viene pulita la coda
			channel.queuePurge(RPC_QUEUE_GET_USER_INFO);
			channel.queuePurge(RPC_QUEUE_ADD_USER);
			channel.queuePurge(RPC_QUEUE_ADD_CC);
			channel.queuePurge(RPC_QUEUE_ALTER_DESCR);
			channel.queuePurge(RPC_QUEUE_DELETE_CC);
			channel.queuePurge(RPC_QUEUE_DELETE_USER);
			channel.queuePurge(RPC_QUEUE_GET_CC_INFO);
			channel.queuePurge(RPC_QUEUE_GET_CC_ID);
			channel.queuePurge(RPC_QUEUE_GET_CC_INFO_USER);
			channel.queuePurge(RPC_QUEUE_GET_SEATS);
			channel.queuePurge(RPC_QUEUE_GET_STATUS);
			channel.queuePurge(RPC_QUEUE_SET_STATUS);
			channel.queuePurge(RPC_QUEUE_GET_USER_ID);
			channel.queuePurge(RPC_QUEUE_GET_USER_INFO_FROM_CC);

			channel.basicQos(1);

			System.out.println(" [x] Awaiting RPC requests");

			Object monitor = new Object();

			// Dichiarazione delle varie delivery

			/***************************************
			 * CALLBACK GET_USER_INFO
			 *************************************/
			DeliverCallback callbackGetUserInfo = (consumerTag, delivery) -> { // procedura avviata all'arrivo di un
																				// messaggio
				GetUserInfo gui = new GetUserInfo(delivery, channel);
				gui.run();
			};

			/***************************************
			 * CALLBACK ADDUSER
			 *************************************/
			DeliverCallback callbackAddUser = (consumerTag, delivery) -> {
				AddUser au = new AddUser(delivery, channel);
				au.run();
			};

			/***************************************
			 * CALLBACK ADDCC
			 *************************************/
			DeliverCallback callbackAddCC = (consumerTag, delivery) -> {
				AddCC acc = new AddCC(delivery, channel);
				acc.run();
			};

			/***************************************
			 * CALLBACK ALTER_DESCRIPTION
			 *************************************/
			DeliverCallback callbackAlterDescr = (consumerTag, delivery) -> {
				AlterDescription ad = new AlterDescription(delivery, channel);
				ad.run();
			};

			/***************************************
			 * CALLBACK DELETECC
			 *************************************/
			DeliverCallback callbackDeleteCC = (consumerTag, delivery) -> {
				DeleteCC dcc = new DeleteCC(delivery, channel);
				dcc.run();
			};

			/***************************************
			 * CALLBACK DELETEUSER
			 *************************************/
			DeliverCallback callbackDeleteUser = (consumerTag, delivery) -> {
				DeleteUser du = new DeleteUser(delivery, channel);
				du.run();
			};

			/***************************************
			 * CALLBACK GET_CC_INFO
			 *************************************/
			DeliverCallback callbackGetCCInfo = (consumerTag, delivery) -> {
				GetCCInfo gcci = new GetCCInfo(delivery, channel);
				gcci.run();
			};
			
			/***************************************
			 * CALLBACK GET_CC_ID
			 *************************************/
			DeliverCallback callbackGetCCID = (consumerTag, delivery) -> {
				GetCCID gccid = new GetCCID(delivery, channel);
				gccid.run();
			};
			
			/***************************************
			 * CALLBACK GET_CC_INFO_USER
			 *************************************/
			DeliverCallback callbackGetCCInfoUser = (consumerTag, delivery) -> {
				GetCCInfoUser gcciu = new GetCCInfoUser(delivery, channel);
				gcciu.run();
			};
			
			/***************************************
			 * CALLBACK GET_SEATS
			 *************************************/
			DeliverCallback callbackGetSeats = (consumerTag, delivery) -> {
				GetSeats gs = new GetSeats(delivery, channel);
				gs.run();
			};
			
			/***************************************
			 * CALLBACK GET_STATUS
			 *************************************/
			DeliverCallback callbackGetStatus = (consumerTag, delivery) -> {
				GetStatus gs = new GetStatus(delivery, channel);
				gs.run();
			};
			
			/***************************************
			 * CALLBACK SET_STATUS
			 *************************************/
			DeliverCallback callbackSetStatus = (consumerTag, delivery) -> {
				SetStatus ss = new SetStatus(delivery, channel);
				ss.run();
			};
			
			/***************************************
			 * CALLBACK GET_USER_ID
			 *************************************/
			DeliverCallback callbackGetUserID = (consumerTag, delivery) -> { 
				GetUserID gui = new GetUserID(delivery, channel);
				gui.run();
			};
			
			/***************************************
			 * CALLBACK GET_USER_INFO_FROM_CC
			 *************************************/
			DeliverCallback callbackGetUserInfoFromCC = (consumerTag, delivery) -> { 
				GetUserInfoFromCC gui = new GetUserInfoFromCC(delivery, channel);
				gui.run();
			};

			/*
			 * Dichiarazione delle varie callback per ogni coda
			 */
			channel.basicConsume(RPC_QUEUE_GET_USER_INFO, false, callbackGetUserInfo, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_ADD_USER, false, callbackAddUser, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_ADD_CC, false, callbackAddCC, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_ALTER_DESCR, false, callbackAlterDescr, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_DELETE_CC, false, callbackDeleteCC, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_DELETE_USER, false, callbackDeleteUser, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_GET_CC_INFO, false, callbackGetCCInfo, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_GET_CC_ID, false, callbackGetCCID, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_GET_CC_INFO_USER, false, callbackGetCCInfoUser, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_GET_SEATS, false, callbackGetSeats, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_GET_STATUS, false, callbackGetStatus, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_SET_STATUS, false, callbackSetStatus, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_GET_USER_ID, false, callbackGetUserID, (consumerTag -> {
			}));
			channel.basicConsume(RPC_QUEUE_GET_USER_INFO_FROM_CC, false, callbackGetUserInfoFromCC, (consumerTag -> {
			}));

			// Wait and be prepared to consume the message from RPC client.
			while (true) {
				synchronized (monitor) {
					try {
						monitor.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		} catch (Exception e) {
		}
		;
	}
}
