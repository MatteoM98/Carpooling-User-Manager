package it.uniupo.matteo.magri.gestoreutenticarpooling;

import io.jsonwebtoken.*;

import javax.naming.CommunicationException;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class TokenVerifier {

    private String realmPublicKey;

    //Costruttore
    public TokenVerifier(PublicKeyRetriever pubRetr) {
        try {
            realmPublicKey = pubRetr.getPublicKey();
        } catch (CommunicationException e) {
            realmPublicKey = null;
        }
    }
    
    public TokenVerifier() {
    	realmPublicKey = null;
    }

    //Metodo per verificare il token
    public boolean verify(String jwt) {
        if(realmPublicKey == null) return false;
        try {
            Jwts.parser()
                    .setSigningKey(getKey(realmPublicKey))
                    .parseClaimsJws(jwt);
            return true;
        } catch (ExpiredJwtException | MalformedJwtException | SignatureException |
                UnsupportedJwtException | IllegalArgumentException e) {
            System.out.println("Token error");
        }
        return false;
    }

    //Metodo che recupera ID dell' utente dal token
    public String getUserId(String jwt) {
        if(realmPublicKey == null) return null;
        Claims claims = Jwts.parser()
                .setSigningKey(getKey(realmPublicKey))
                .parseClaimsJws(jwt).getBody();
        return claims.getSubject();
    }

    //Restituisce chiave pubblica in formato PublicKey, usato poi dal parser
    public static PublicKey getKey(String key){
        try{
            byte[] byteKey = Base64.getDecoder().decode(key.getBytes());
            X509EncodedKeySpec X509publicKey = new X509EncodedKeySpec(byteKey);
            KeyFactory kf = KeyFactory.getInstance("RSA");

            return kf.generatePublic(X509publicKey);
        }
        catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }

}



