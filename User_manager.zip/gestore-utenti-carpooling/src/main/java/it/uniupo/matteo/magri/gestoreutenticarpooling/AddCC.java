package it.uniupo.matteo.magri.gestoreutenticarpooling;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Delivery;

public class AddCC extends Thread {
	// Variabili
	private Delivery delivery;
	private Channel channel;

	// JDBC driver e URL database
	private final static String JDBC_DRIVER = "org.h2.Driver";
	private final static String DB_URL = "jdbc:h2:/home/enigma/test";
	// Credenziali databse
	private final static String USERDB = "matteo";
	private final static String PASSDB = "";

	// Costruttore
	public AddCC(Delivery delivery, Channel channel) {
		this.delivery = delivery;
		this.channel = channel;
	}

	@Override
	public void run() {
		AMQP.BasicProperties replyProps = new AMQP.BasicProperties.Builder()
				.correlationId(delivery.getProperties().getCorrelationId()).build();

		String response = ""; // stringa di risposta da inviare indietro

		try {
			// Leggo la richiesta
			String message = new String(delivery.getBody(), "UTF-8");
			System.out.println("Operazione richiesta: addCC");
			// elaboro message
			JSONObject obj = new JSONObject(message);
			String token = obj.getString("token");
			JSONObject param = obj.getJSONObject("param");
			String descr = param.getString("descr");
			String nposti = param.getString("nposti");
			// Verificare il token
			PublicKeyRetriever key = new PublicKeyRetriever("localhost", "Demo", 8080);
			TokenVerifier tokenVer = new TokenVerifier(key);
			String userId = tokenVer.getUserId(token);
			if (tokenVer.verify(token)) {
				// Se la verifica va a termine, contatto il DB
				Connection conn = null;
				Statement stmt = null;
				Class.forName(JDBC_DRIVER);
				System.out.println("Connessione al database...");
				conn = DriverManager.getConnection(DB_URL, USERDB, PASSDB);
				System.out.println("Connessione eseguita con successo!!!");
				stmt = conn.createStatement();
				String ccID = UUID.randomUUID().toString();
				String sql = "INSERT INTO CARCONTROLLER (ID, Descrizione, NumeroPosti, Stato) VALUES (\'" + ccID + "\',"
						+ "\'" + descr + "\'," + "\'" + nposti + "\'," + "\'" + "ON" + "\')";
				int rs = stmt.executeUpdate(sql);
				if (rs > 0) {
					sql = "INSERT INTO PROPRIETARICC (IDUtente, IDcc) VALUES (\'" + userId + "\'," + "\'" + ccID
							+ "\')";
					rs = stmt.executeUpdate(sql);
					if (rs > 0) {
						response = "CC added";
					} else {
						response = "Resource error";
					}
				} else
					response = "Resource error";

			} else {
				// Altrimenti restituisco un token error
				response = "Token error";
			}
		} catch (RuntimeException | JSONException e) {
			response = "Resource error";
		} catch (ClassNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Credenziali errate");
			e.printStackTrace();
		} finally {
			try {
				channel.basicPublish("", delivery.getProperties().getReplyTo(), replyProps, response.getBytes("UTF-8")); // pubblica
																															// la
																															// risposta
				channel.basicAck(delivery.getEnvelope().getDeliveryTag(), false);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
