CREATE TABLE Utente
(
    ID VARCHAR(50) PRIMARY KEY,
    Nome VARCHAR(20) not null,
    Cognome VARCHAR(20) not null,
    Email VARCHAR(64) not null,
    DoB date NOT NULL,
    Username VARCHAR(64) UNIQUE NOT NULL
);

CREATE TABLE CarController
(
    ID VARCHAR(50) PRIMARY KEY,
    Descrizione text not null,
    NumeroPosti SMALLINT DEFAULT 2,
    Stato VARCHAR(3) not null DEFAULT 'OFF'
);

create TABLE ProprietariCC
(
    IDUtente VARCHAR(50) REFERENCES Utente(ID) on DELETE CASCADE,
    IDcc VARCHAR(50) REFERENCES CarController(ID) on DELETE CASCADE,
    PRIMARY KEY(IDUtente, IDcc)
);
